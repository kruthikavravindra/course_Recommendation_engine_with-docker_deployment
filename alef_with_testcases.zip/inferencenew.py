#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import platform
import sys
import numpy
import scipy
import os
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.neighbors import KNeighborsClassifier
import pickle

def test_inference():
    # Load the trained model and encoding scheme
    with open('model.pkl', 'rb') as f:
        knn = pickle.load(f)

    with open('encoding.pkl', 'rb') as f:
        ct = pickle.load(f)

    # Load the test data and apply encoding
    test_data = pd.read_csv('test.csv')
    X_test = ct.transform(test_data)

    # Make predictions using the trained model
    y_pred = knn.predict(X_test)

    # Check the shape of the predictions array
    assert y_pred.shape == (test_data.shape[0],)

def inference():
    # Load the trained model and encoding scheme
    with open('model.pkl', 'rb') as f:
        knn = pickle.load(f)

    with open('encoding.pkl', 'rb') as f:
        ct = pickle.load(f)

    # Load the new data from a CSV file
    test = "./test.csv"
    data= pd.read_csv(test)
    new_data = pd.read_csv('test.csv')

    # Apply the encoding scheme to the new data
    X_new = ct.transform(new_data)

    # Make predictions using the trained model
    y_pred = knn.predict(X_new)
    y_pred=pd.DataFrame(y_pred,columns=['Recommended_course'])
    new_data=pd.concat([new_data,y_pred],axis=1)
    print(new_data)
    
if __name__ == '__main__':
    test_inference()
    inference()

