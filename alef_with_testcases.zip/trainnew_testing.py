#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import unittest
import numpy as np
from sklearn import preprocessing
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
import pickle

class TestModels(unittest.TestCase):
    def test_DataLoader(self):
        dl = DataLoader("./train.csv")
        X, y = dl.load_data()
        self.assertEqual(X.shape, (100, 3))
        self.assertEqual(y.shape, (100,))
    
    def test_KNNModel(self):
        model = KNNModel(k=5)
        dl = DataLoader("./train.csv")
        X, y = dl.load_data()
        model.train(X, y)
        preds = model.predict(X)
        self.assertEqual(preds.shape, y.shape)
    
    def test_train(self):
        dl = DataLoader("./train.csv")
        model = KNNModel(k=5)
        train(dl, model)
        self.assertTrue(os.path.exists('model.pkl'))
        self.assertTrue(os.path.exists('encoding.pkl'))


if __name__ == '__main__':
    unittest.main()

