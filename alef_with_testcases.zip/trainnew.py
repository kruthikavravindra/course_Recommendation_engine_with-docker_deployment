#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import numpy as np
from sklearn import preprocessing
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
import pickle

class DataLoader:
    def __init__(self, filepath):
        self.filepath = filepath
    
    def load_data(self):
        data = pd.read_csv(self.filepath)
        X = data.drop('course', axis=1)
        y = data['course']
        return X, y

class KNNModel:
    def __init__(self, k=5):
        self.k = k
        self.knn = KNeighborsClassifier(n_neighbors=k)
    
    def train(self, X, y):
        # Define the categorical columns and apply one-hot encoding
        cat_cols = ['gender', 'stream', 'subject']
        ct = ColumnTransformer([('encoder', OneHotEncoder(), cat_cols)], remainder='passthrough')
        X = ct.fit_transform(X)

        # Train the k-NN classifier
        self.knn.fit(X, y)

        # Save the encoding scheme
        self.encoding = ct
    
    def predict(self, X):
        # Apply encoding scheme to new data
        X = self.encoding.transform(X)

        # Make predictions
        return self.knn.predict(X)
        

def train(data_loader, model):
    # Load and preprocess data
    X, y = data_loader.load_data()

    # Split the data into training and testing sets
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    model.train(X_train, y_train)

    # Save the trained model and encoding scheme
    with open('model.pkl', 'wb') as f:
        pickle.dump(model, f)
        
if __name__ == '__main__':
    data_loader = DataLoader("./train.csv")
    model = KNNModel(k=5)
    train(data_loader, model)

